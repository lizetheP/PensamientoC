a = int(input())
b = int(input())
c = int(input())
aux = a / b
print("%.3f" % aux)
aux = a % b
print(aux)
aux = a / b - c
print("%.3f" % aux)
aux = a / (b - c)
print("%.3f" % aux)
