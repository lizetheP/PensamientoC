r = int(input())
h = int(input())
PI = 3.141592
aux = 1/3*PI*r*r*h
print("%.3f" % aux)

