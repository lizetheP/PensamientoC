import math

A = float(input())
C = float(input())
B = math.sqrt(math.pow(C,2) - math.pow(A,2))
print("%.2f" % B)