import math

PI = 3.141592
r = float(input())
h = float(input())
v = (PI*math.pow(r,2)*h)/2 
print("%.3f" % v)

