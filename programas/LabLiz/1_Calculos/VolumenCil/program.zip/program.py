import math

PI = 3.141592
r = float(input())
h1 = float(input())
h2 = float(input())
v = (PI*math.pow(r,2)*(h1+h2))/2 
print("%.2f" % v)

